export const environment = {
    url: 'http://localhost/webuy'
}