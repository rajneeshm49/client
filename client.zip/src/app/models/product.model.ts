export class ProductModel {
    title: String;
    category: Number;
    description: String;
    image: File;
    price: Number;
}