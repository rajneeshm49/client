export class CategoryModel {
    category_name: String;
}